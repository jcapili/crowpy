import crowpy

cp = CrowPy()
cp.calculateMiles('9405509206119000255830')